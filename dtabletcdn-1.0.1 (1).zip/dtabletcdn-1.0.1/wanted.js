$(function () {
  $('#dato').datetimepicker({
    locale: 'da',
    icons: {
      time: "fas fa-clock",
      date: "fa fa-calendar",
      up: "fa fa-arrow-up",
      down: "fa fa-arrow-down"
    }
  });
});
